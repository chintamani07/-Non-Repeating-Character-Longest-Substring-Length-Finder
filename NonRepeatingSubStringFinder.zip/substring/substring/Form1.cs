﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace substring
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int LengthOfLongestSubstring(string s)
        {
            int maxLength = 0;
            int[] charIndex = new int[256];
            int i = 0;

            for (int j = 0; j < s.Length; j++)
            {
                i = Math.Max(charIndex[s[j]], i);
                maxLength = Math.Max(maxLength, j - i + 1);
                charIndex[s[j]] = j + 1;
            }

            return maxLength;
        }

        private int LengthOfLongestNullSubstring(string s)
        {
            int minLength = 0;
            int[] charIndex = new int[256];
            int i=0;

            for (int j = 0; j < s.Length; j++)
            {
                i = Math.Max(charIndex[s[j]], i);
                minLength = Math.Max(minLength, j - i + 1);
                charIndex[s[j]] = j + 1;
            }

            return minLength;
        }

        private string LongestSubstringWithoutRepeatingCharacters(string s)
        {
            int maxLength = 0;
            int[] charIndex = new int[256];
            int start = 0;
            int end = 0;

            for (int j = 0; j < s.Length; j++)
            {
                start = Math.Max(charIndex[s[j]], start);
                if (j - start + 1 > maxLength)
                {
                    maxLength = j - start + 1;
                    end = j;
                }
                charIndex[s[j]] = j + 1;
            }

            return s.Substring(end - maxLength + 1, maxLength);
        }

        private string LongestSubstringWithNullInput(string s)
        {
            int minLength = 1;
            int[] charIndex = new int[256];
            int start = 0;
            int end = 0;

            for (int j = 0; j < s.Length; j++)
            {
                start = Math.Max(charIndex[s[j]], start);
                if (j - start + 1 > minLength)
                {
                    minLength = j - start + 1;
                    end = j;
                }
                charIndex[s[j]] = j + 1;
            }

            return s.Substring(end - minLength + 1, minLength);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Output.Visible = true;

            //string input = textBox1.Text;
            //int maxLength = LengthOfLongestSubstring(input);
            //label2.Text = "Length of longest substring without repeating characters: " + maxLength;

            string input = txt_string.Text;
            if (input.Length > 5 * 104)
            {
                MessageBox.Show("Input string length exceeds the maximum allowed length.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if(input.Length==0)
            {
                try
                {
                    int minLength = LengthOfLongestNullSubstring(input);
                    string longestNullSubstring = LongestSubstringWithNullInput(input);
                }
                catch {
                    DialogResult result = MessageBox.Show("Input String Must Be Greater Than 0!!", "NULL Value Exception", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    return;
                }
            }
            else
            {

                int maxLength = LengthOfLongestSubstring(input);
                string longestSubstring = LongestSubstringWithoutRepeatingCharacters(input);
                Output.Text = string.Format("Longest substring without repeating characters: '{0}', Length: {1}", longestSubstring, maxLength);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Output.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt_string.Text = "";
        }
    }
}
